function g = imageTranslate(f, tx, ty)
    [m, n] = size(f);

    % Fundo branco
    if isa(f, 'uint8')
        g_double = 255 * ones(m, n);
    elseif isa(f, 'uint16')
        g_double = 65535 * ones(m, n);
    else
        g_double = ones(m, n);
    end

    % Mapeamento inverso
    for xp = 1:m
        for yp = 1:n

            x = xp - tx;
            y = yp - ty;

            % Interpola se a coordenada vier de dentro da imagem original
            if x >= 1 && x <= m && y >= 1 && y <= n
                g_double(xp, yp) = bilinearInterp(f, x, y);
            end

        end
    end

    % Converter para o mesmo tipo da imagem original
    if isa(f, 'uint8')
        g = uint8(round(g_double));
    elseif isa(f, 'uint16')
        g = uint16(round(g_double));
    else
        g = g_double;
    end
end