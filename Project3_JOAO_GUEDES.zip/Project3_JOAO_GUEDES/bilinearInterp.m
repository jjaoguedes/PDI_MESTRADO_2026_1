function p = bilinearInterp(f, x, y)

[m,n]=size(f); %tamanho da imagem original

xi = floor(x); %arrendondamento pra baixo
yi = floor(y); %arrendondamento pra baixo

%condi��o para xi e yi n�o ser menor ou igual a 0
if (xi<=0) 
   xi = 1;
end
if (yi<=0)
   yi = 1;
end

%condi��o para xi1 e yi1 n�o serem maiores que o tamanho da imagem original
if(xi+1)>m
    xi = m-1; 
end
if(yi+1)>n 
    yi = n-1; 
end

xi1 = xi+1;
yi1 = yi+1;

A1 = [1 xi yi xi*yi; 1 xi1 yi xi1*yi; 1 xi yi1 xi*yi1; 1 xi1 yi1 xi1*yi1];
B = double([f(xi,yi); f(xi1,yi); f(xi,yi1); f(xi1,yi1)]);
X = linsolve(A1,B);

p = X(1) + X(2)*x + X(3)*y + X(4)*x*y;
end