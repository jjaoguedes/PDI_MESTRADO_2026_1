function g = imageZoom(f, cx, cy)

    if cx <= 0 || cy <= 0
        error('cx e cy devem ser números reais positivos.');
    end

    [m, n] = size(f);

    % Tamanho da imagem ampliada/reduzida
    mz = round(m * cx);
    nz = round(n * cy);

    % Imagem temporária após o zoom
    zoomed = zeros(mz, nz);

    % Mapeamento inverso
    % Para cada pixel da imagem de saída, busca a posição correspondente na original
    for xz = 1:mz
        for yz = 1:nz

            % Coordenadas correspondentes na imagem original
            x = (xz - 0.5) / cx + 0.5;
            y = (yz - 0.5) / cy + 0.5;

            % Interpolação bilinear
            zoomed(xz, yz) = bilinearInterp(f, x, y);
        end
    end

    % Cria imagem final com o mesmo tamanho da original
    g_double = zeros(m, n);

    % Caso a imagem com zoom seja maior ou igual à original, recorta o centro
    if mz >= m && nz >= n

        start_x = floor((mz - m) / 2) + 1;
        start_y = floor((nz - n) / 2) + 1;

        g_double = zoomed(start_x:start_x+m-1, start_y:start_y+n-1);

    else
        % Caso cx ou cy seja menor que 1, centraliza a imagem reduzida
        start_x = floor((m - mz) / 2) + 1;
        start_y = floor((n - nz) / 2) + 1;

        g_double(start_x:start_x+mz-1, start_y:start_y+nz-1) = zoomed;
    end

    % Converte para o mesmo tipo da imagem original
    if isa(f, 'uint8')
        g = uint8(round(g_double));
    elseif isa(f, 'uint16')
        g = uint16(round(g_double));
    else
        g = g_double;
    end
end