function g = imageResize(f, numrows, numcols)

    originalClass = class(f);

    f = double(f);

    % Tamanho da imagem original
    [m, n] = size(f);

    % Fator de escala mantendo proporção
    escala_linhas = numrows / m;
    escala_colunas = numcols / n;
    escala = min(escala_linhas, escala_colunas);

    % Novo tamanho proporcional
    newrows = round(m * escala);
    newcols = round(n * escala);

    % Imagem de saída preenchida com branco
    g = 255 * ones(numrows, numcols);

    % Centraliza a imagem redimensionada
    rowOffset = floor((numrows - newrows) / 2);
    colOffset = floor((numcols - newcols) / 2);

    % Percorre apenas o local onde a imagem redimensionada será colocada
    for i = 1:newrows
        for j = 1:newcols

            % Mapeamento inverso: saída -> imagem original
            if newrows == 1
                x = 1;
            else
                x = 1 + (i - 1) * (m - 1) / (newrows - 1);
            end

            if newcols == 1
                y = 1;
            else
                y = 1 + (j - 1) * (n - 1) / (newcols - 1);
            end

            % Interpolação bilinear
            valor = bilinearInterp(f, x, y);

            % Coloca o pixel na posição correta da imagem final
            g(rowOffset + i, colOffset + j) = valor;
        end
    end

    % Garante que os valores fiquem entre 0 e 255
    g = max(0, min(255, g));

    % Volta para a classe original
    if strcmp(originalClass, 'uint8')
        g = uint8(g);
    end
end