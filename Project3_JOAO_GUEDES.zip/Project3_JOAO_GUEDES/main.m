clear;
clc;
close all;

% Pasta onde estão as imagens
pasta = 'Covid';

% Extensões aceitas
arquivos = [dir(fullfile(pasta, '*.png'))];

for k = 1:length(arquivos)

    nomeArquivo = arquivos(k).name;
    caminhoImagem = fullfile(pasta, nomeArquivo);

    % Ignora imagens já transformadas
    if contains(nomeArquivo, 'Transformada')
        continue;
    end

    f = imread(caminhoImagem);

    % Converter para grayscale, caso seja RGB
    if size(f, 3) == 3
        f = rgb2gray(f);
    end

    % Redimensionar para 224x224
    f = imageResize(f, 224, 224);

    % Separar nome e extensão
    [~, nomeBase, ext] = fileparts(nomeArquivo);

    % 1) Translação: 7 pixels em x e 0 em y
    g1 = imageTranslate(f, 7, 0);
    imwrite(g1, fullfile(pasta, [nomeBase '_xTransformada_7' ext]));

    % 2) Translação: 0 em x e 10 pixels em y
    g2 = imageTranslate(f, 0, 10);
    imwrite(g2, fullfile(pasta, [nomeBase '_yTransformada_10' ext]));

    % 3) Zoom 1.05 nas duas direções
    g3 = imageZoom(f, 1.05, 1.05);
    imwrite(g3, fullfile(pasta, [nomeBase '_zoomTransformada_105' ext]));

    % 4) Zoom 1.10 nas duas direções
    g4 = imageZoom(f, 1.10, 1.10);
    imwrite(g4, fullfile(pasta, [nomeBase '_zoomTransformada_110' ext]));

    % 5) Reflexão horizontal
    g5 = imageReflection(f, 'y');
    imwrite(g5, fullfile(pasta, [nomeBase '_reflexaoHorizontalTransformada' ext]));

    fprintf('Imagem processada: %s\n', nomeArquivo);
end

disp('Todas as imagens foram processadas.');