function g = imageReflection(f, mode)

    [m, n] = size(f);

    % Imagem de saída com mesmo tamanho e mesma classe de f
    g = zeros(m, n, class(f));

    if mode == 'x'
        % Reflexão no eixo x: inverte as linhas
        for i = 1:m
            for j = 1:n
                g(i, j) = f(m - i + 1, j);
            end
        end

    elseif mode == 'y'
        % Reflexão no eixo y: inverte as colunas
        for i = 1:m
            for j = 1:n
                g(i, j) = f(i, n - j + 1);
            end
        end

    else
        error("Modo inválido");
    end
end