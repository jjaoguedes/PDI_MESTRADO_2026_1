
clc;

% Leitura da imagem
f = imread("spillway-dark.tif");

f = double(f);

% nível de intensidade
L = 256;

% tamanho da imagem
[M, N] = size(f);
g = zeros(M, N);

% coeficientes da função linear
a = -1;
b = L-1;

% Aplicação da transformada pixel a pixel 
for x = 1:M
    for y = 1:N
        % Função linear aplicada do complemento
        g(x,y) = b - f(x,y);
    end
end

% Salvamento da imagem em tif
imwrite(uint8(g), 'spillway-dark-negative.tif')

