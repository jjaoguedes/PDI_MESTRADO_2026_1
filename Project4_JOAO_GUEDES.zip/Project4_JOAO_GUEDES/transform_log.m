clc;

% Leitura da imagem
f = imread("spillway-dark.tif");

f = double(f);

% tamanho da imagem
[M, N] = size(f);
g = zeros(M, N);

% valore máximo da intensidade da imagem original
fmax = max(max(f(:)));

% parâmetro com maior intensidade máxima da imagem
c = 255/(log(1 + fmax));

% Aplicação da transformada pixel a pixel 
for x = 1:M
    for y = 1:N
        % Aplicação da transformada logarítmica
        g(x,y) = c * log (1 + f(x,y));
    end
end

% Salvamento da imagem em tif
imwrite(uint8(g), 'spillway-dark-log.tif')

