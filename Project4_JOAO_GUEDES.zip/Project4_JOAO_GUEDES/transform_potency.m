clc;

%Leitura da imagem
f = imread("spillway-dark.tif");

f = double(f);

% tamanho da imagem
[M, N] = size(f);

g = ones(M, N);

% constante
c = 1;

% valor de gama na transformação de potência
gama = 1.5;

% Aplicação da transformada pixel a pixel 
for x = 1:M
    for y = 1:N
        % Função de transformação da potência
        g(x,y) = c * ((f(x,y))^gama);
    end
end

% Salvamento da imagem em tif
imwrite(uint8(g), 'spillway-dark-gama.tif')

