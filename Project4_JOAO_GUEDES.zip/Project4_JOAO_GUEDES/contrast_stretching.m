clc;

%Leitura da imagem
f = imread("spillway-dark.tif");

f = double(f);

% Nível de intensidade
L = 256;

% tamanho da imagem
[M, N] = size(f);

g = zeros(M, N);

% valores máximo e minímo da intensidade da imagem original
fmin = min(f(:));
fmax = max(f(:));

% Aplicação da transformada pixel a pixel 
for x = 1:M
    for y = 1:N
            % Função de transformação re-scaling
            g(x,y) = ((255)/(fmax-fmin)) * (f(x,y)-fmin);
    end
end

% Salvamento da imagem em tif
imwrite(uint8(g), 'spillway-dark-contrast-stretch.tif')

