% (b) Comparação de Histogramas Não Normalizados
f = imread('magnified-pollen-dark.tif');

% Usando a função imagehist (não normalizada)
[h_manual, ~] = imagehist(f, 'u');

% Usando a função imhist do IPT
h_ipt = imhist(f);

figure;
subplot(1,2,1); bar(0:255, h_manual); title('imagehist (Manual - Modo u)');
subplot(1,2,2); bar(0:255, h_ipt); title('imhist (Matlab IPT)');
% Explicação: Ambos devem ser idênticos, pois o histograma é a contagem nk[cite: 14, 16].

% Equalização usando IPT histeq
g_ipt = histeq(f);

% Equalização usando histeq2 (Manual)
[g_manual, T_manual] = histeq2(f);

% Comparação 
% Visualização das imagens
figure;
subplot(1,3,1); imshow(f); title('Original (Escura)');
subplot(1,3,2); imshow(g_ipt); title('Equalizada (IPT histeq)');
subplot(1,3,3); imshow(g_manual); title('Equalizada (histeq2)');

% Comparação dos histogramas
figure;
subplot(1,2,1); imhist(g_ipt); title('Histograma IPT');
subplot(1,2,2); imhist(g_manual); title('Histograma histeq2');