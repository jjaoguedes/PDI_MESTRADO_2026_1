function [g, T] = imagehist(f, mode)

% Define o modo padrão como normalizado se não for especificado
if nargin < 2
    mode = 'n';
end

% Inicializa o vetor do histograma
g = zeros(1, 256);
T = 0:255;

% Obtém o tamanho da imgem
[M, N] = size(f);
n_total = M * N;

% Percorre cada pixel da imagem e conta as ocorrências (nk)
for i = 1:M
    for j = 1:N
        intensidade = f(i, j);
        g(intensidade + 1) = g(intensidade + 1) + 1;
    end
end

% Verifica se deve normalizar o histograma
if mode == 'n'
    % Normaliza dividindo o número de ocorrências pelo total de pixels
    % Fornece a probabilidade p(rk) de cada nível
    g = g / n_total;
end
end