function [g, T] = histeq2(f)

    % Preserva a classe original e converte para double
    classe_original = class(f);
    f_double = double(f);

    % Normaliza a entrada se for double para o intervalo [0, 255]
    % Se for uint8, os valores são mantidos para indexação
    if strcmp(classe_original, 'double')
        f_trabalho = f_double * 255;
    else
        f_trabalho = f_double;
    end

    % Calcula o Histograma Normalizado (pr) usando 256 níveis
    L = 256;
    h = zeros(1, L);
    [M, N] = size(f_trabalho);
    n_total = M * N;

    for i = 1:M
        for j = 1:N
            % Garante que o índice esteja entre 1 e 256
            val = floor(f_trabalho(i, j)) + 1;
            val = min(max(val, 1), L); 
            h(val) = h(val) + 1;
        end
    end
    % Histograma normalizado
    pr = h / n_total; 

    % Calcula a Função de Distribuição Acumulada
    % sk = (L-1) * sum(prj) para j=0 até k
    T = zeros(1, L);
    soma_acumulada = 0;
    K = L - 1;

    for k = 1:L
        soma_acumulada = soma_acumulada + pr(k);
        T(k) = K * soma_acumulada;
    end

    % Mapeia os pixels da imagem original para os novos valores
    g_trabalho = zeros(M, N);
    % Arredondamento dos valores conforme a quantização
    T_quantizado = round(T); 

    for i = 1:M
        for j = 1:N
            idx = floor(f_trabalho(i, j)) + 1;
            idx = min(max(idx, 1), L);
            g_trabalho(i, j) = T_quantizado(idx);
        end
    end

    % Converte o resultado de volta para a classe original
    if strcmp(classe_original, 'double')
        g = g_trabalho / 255;
    elseif strcmp(classe_original, 'uint8')
        g = uint8(g_trabalho);
    elseif strcmp(classe_original, 'uint16')
        g = uint16(g_trabalho);
    end
end