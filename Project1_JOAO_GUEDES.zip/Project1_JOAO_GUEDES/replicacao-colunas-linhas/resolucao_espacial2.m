%==============================
% ampliação de um fator de 2
%==============================
I=imread('Fig0219_rose256to512.tif');
[M, N]=size(I);
S  = zeros(M, 2*N, 'uint8');
SS = zeros(2*M, 2*N, 'uint8');
%replicando colunas
for c=1:1:N
S(:,2*c)=I(:,c);
S(:,(2*c-1))=S(:,2*c);
end
%replicando linhas:
for r=1:1:M
SS(2*r,:)=S( r,:);
SS((2*r-1),:)=SS(2*r,:);
end

imwrite(SS, 'Fig0219_rose512to1024.tif');