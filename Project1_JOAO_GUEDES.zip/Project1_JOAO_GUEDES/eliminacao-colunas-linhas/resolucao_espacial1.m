%==============================
% redução de um fator de 2
%==============================
I=imread('Fig0219_rose64.tif');
[M N]=size(I);
M1=M/2;
N1=N/2;
RC= zeros(M,N1, 'uint8');
S1=zeros(M1, N1, 'uint8');
%eliminando colunas pares:
for c=1:2:N
cc=uint16(c/2);
RC(:,cc)=I(:,c);
end
%eliminando linhas pares:
for r=1:2:M
rr=uint16(r/2);
S1(rr,:)=RC(r,:);
end

imwrite(S1, 'Fig0219_rose32.tif');